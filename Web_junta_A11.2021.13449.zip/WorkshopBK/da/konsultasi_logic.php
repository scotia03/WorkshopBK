<?php
require '../../config/koneksi.php';
session_start();

if ($_SESSION['akses'] != "pasien") {
    header("Location: ../../unauthorized.php");
    exit();
}

$pasien_id = $_SESSION['id']; 
$error = null;
$success = null;


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = $_POST['subject'];
    $pertanyaan = $_POST['pertanyaan'];
    $id_dokter = $_POST['id_dokter'];

    $insertQuery = "INSERT INTO konsultasi (subject, pertanyaan, tgl_konsultasi, id_pasien, id_dokter) 
                    VALUES (?, ?, NOW(), ?, ?)";
    $stmt = $mysqli->prepare($insertQuery);
    $stmt->bind_param("ssii", $subject, $pertanyaan, $pasien_id, $id_dokter);

    if ($stmt->execute()) {
        header("Location: ../../konsultasi_pasien.php?success=1"); 
    } else {
        $error = "Gagal mengirim konsultasi: " . $mysqli->error;
    }
}

// Fetch list of doctors
$dokterQuery = "SELECT id, nama FROM dokter";
$dokterResult = $mysqli->query($dokterQuery);
$dokters = [];
while ($row = $dokterResult->fetch_assoc()) {
    $dokters[] = $row;
}

// Fetch consultation history for the patient
$historyQuery = "SELECT k.subject, k.pertanyaan, k.jawaban, k.tgl_konsultasi, d.nama AS dokter 
                 FROM konsultasi k
                 INNER JOIN dokter d ON k.id_dokter = d.id
                 WHERE k.id_pasien = ?";
$stmt = $mysqli->prepare($historyQuery);
$stmt->bind_param("i", $pasien_id);
$stmt->execute();
$historyResult = $stmt->get_result();
$consultationHistory = [];
while ($row = $historyResult->fetch_assoc()) {
    $consultationHistory[] = $row;
}
?>
