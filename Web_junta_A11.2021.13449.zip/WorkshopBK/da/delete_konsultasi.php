<?php
require '../../config/koneksi.php';

if (!isset($_GET['id'])) {
    header('location:../../konsultasi_pasien.php');
    exit;
}

$id = $_GET['id'];
$query = "DELETE FROM konsultasi WHERE id = $id";
mysqli_query($mysqli, $query);

header('location:../../konsultasi_pasien.php');
exit;
?>
