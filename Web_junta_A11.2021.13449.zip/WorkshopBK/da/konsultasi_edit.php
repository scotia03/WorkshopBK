<?php
session_start();
require 'config/koneksi.php';

if ($_SESSION['akses'] != "dokter") {
    header("location:login.php");
}

$id_dokter = $_SESSION['id'];
$id_konsultasi = $_GET['id'];

// Ambil data konsultasi
$query = "SELECT * FROM konsultasi WHERE id = '$id_konsultasi' AND id_dokter = '$id_dokter'";
$result = mysqli_query($mysqli, $query);
$konsultasi = mysqli_fetch_assoc($result);

if (!$konsultasi) {
    echo "Data tidak ditemukan atau Anda tidak memiliki akses.";
    exit;
}

// Jika form di-submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $jawaban = mysqli_real_escape_string($mysqli, $_POST['jawaban']);

    $updateQuery = "UPDATE konsultasi SET jawaban = '$jawaban' WHERE id = '$id_konsultasi' AND id_dokter = '$id_dokter'";
    if (mysqli_query($mysqli, $updateQuery)) {
        header("Location: konsultasi_dokter.php");
        exit;
    } else {
        echo "Gagal mengupdate konsultasi: " . mysqli_error($mysqli);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Konsultasi</title>
    <link rel="stylesheet" href="assets/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="assets/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include('components/navbar.php') ?>
        <!-- Sidebar -->
        <?php include('components/sidebar.php') ?>

        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Edit Konsultasi</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                                <li class="breadcrumb-item active">Edit Konsultasi</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <section class="content">
                <div class="container-fluid">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Edit Jawaban Konsultasi</h3>
                        </div>
                        <form method="post">
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="subject">Subject</label>
                                    <input type="text" class="form-control" id="subject" value="<?php echo $konsultasi['subject']; ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="pertanyaan">Pertanyaan</label>
                                    <textarea class="form-control" id="pertanyaan" rows="4" disabled><?php echo $konsultasi['pertanyaan']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="jawaban">Jawaban</label>
                                    <textarea name="jawaban" class="form-control" id="jawaban" rows="4" required><?php echo $konsultasi['jawaban']; ?></textarea>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <a href="konsultasi_dokter.php" class="btn btn-secondary">Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/dist/js/adminlte.min.js"></script>
</body>

</html>
