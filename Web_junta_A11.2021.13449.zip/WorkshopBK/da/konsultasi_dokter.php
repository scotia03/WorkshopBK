<!DOCTYPE html>
<?php
session_start();
$username = $_SESSION['username'];
$id_dokter = $_SESSION['id']; // Assuming dokter's ID is stored in session

if ($username == "" || $_SESSION['akses'] != "dokter") {
    header("location:login.php");
}
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Konsultasi Dokter</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="assets/plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="assets/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <!-- Navbar -->
        <?php include('components/navbar.php') ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include('components/sidebar.php') ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Konsultasi</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                                <li class="breadcrumb-item active">Konsultasi</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Daftar Konsultasi Anda</h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Subject</th>
                                        <th>Pertanyaan</th>
                                        <th>Jawaban</th>
                                        <th>Pasien</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    require 'config/koneksi.php';
                                    $query = "SELECT k.id, k.subject, k.pertanyaan, k.jawaban, p.nama AS pasien, k.tgl_konsultasi
                                              FROM konsultasi k
                                              INNER JOIN pasien p ON k.id_pasien = p.id
                                              WHERE k.id_dokter = '$id_dokter'";
                                    $result = mysqli_query($mysqli, $query);
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>
                                                <td>{$row['id']}</td>
                                                <td>{$row['subject']}</td>
                                                <td>{$row['pertanyaan']}</td>
                                                <td>" . ($row['jawaban'] ?: 'Belum Dijawab') . "</td>
                                                <td>{$row['pasien']}</td>
                                                <td>{$row['tgl_konsultasi']}</td>
                                                <td>";
                                                if ($row['jawaban']) {
                                                    echo "<a href='konsultasi_edit.php?id={$row['id']}' class='btn btn-sm btn-warning'>Edit</a>";
                                                } else {
                                                    echo "<a href='konsultasi_jawab.php?id={$row['id']}' class='btn btn-sm btn-primary'>Jawab</a>";
                                                }
                                        echo "</td>
                                            </tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <div class="p-3">
                <h5>Title</h5>
                <p>Halo</p>
            </div>
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/dist/js/adminlte.min.js"></script>
</body>

</html>
