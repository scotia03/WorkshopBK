<?php
session_start();
require 'config/koneksi.php';

if ($_SESSION['akses'] != "pasien") {
    header("location:login.php");
}

$id_pasien = $_SESSION['id'];
$id_konsultasi = $_GET['id'];

// Ambil data konsultasi
$query = "SELECT * FROM konsultasi WHERE id = '$id_konsultasi' AND id_pasien = '$id_pasien'";
$result = mysqli_query($mysqli, $query);
$konsultasi = mysqli_fetch_assoc($result);

if (!$konsultasi) {
    echo "Data tidak ditemukan atau Anda tidak memiliki akses.";
    exit;
}

// Jika form di-submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = mysqli_real_escape_string($mysqli, $_POST['subject']);
    $pertanyaan = mysqli_real_escape_string($mysqli, $_POST['pertanyaan']);

    $updateQuery = "UPDATE konsultasi SET subject = '$subject', pertanyaan = '$pertanyaan' WHERE id = '$id_konsultasi' AND id_pasien = '$id_pasien'";
    if (mysqli_query($mysqli, $updateQuery)) {
        header("Location: konsultasi_pasien.php");
        exit;
    } else {
        echo "Gagal mengupdate konsultasi: " . mysqli_error($mysqli);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Konsultasi</title>
    <link rel="stylesheet" href="assets/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="assets/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include('components/navbar.php') ?>
        <!-- Sidebar -->
        <?php include('components/sidebar.php') ?>

        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Edit Konsultasi</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                                <li class="breadcrumb-item active">Edit Konsultasi</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <section class="content">
                <div class="container-fluid">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Edit Konsultasi Anda</h3>
                        </div>
                        <form method="post">
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="subject">Subject</label>
                                    <input type="text" name="subject" class="form-control" id="subject" value="<?php echo $konsultasi['subject']; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="pertanyaan">Pertanyaan</label>
                                    <textarea name="pertanyaan" class="form-control" id="pertanyaan" rows="4" required><?php echo $konsultasi['pertanyaan']; ?></textarea>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <a href="konsultasi.php" class="btn btn-secondary">Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/dist/js/adminlte.min.js"></script>
</body>

</html>
