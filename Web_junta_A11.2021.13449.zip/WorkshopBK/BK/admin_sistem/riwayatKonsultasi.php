<?php
session_start();
require 'db.php'; // Menggunakan koneksi PDO

// Query untuk mengambil data riwayat konsultasi
$query = $pdo->prepare("
    SELECT k.id, k.keluhan, k.pertanyaan, k.jawaban, k.tgl_konsultasi, d.nama AS nama_dokter
    FROM konsultasi k
    JOIN dokter d ON k.id_dokter = d.id
    WHERE k.id = :id
    ORDER BY k.tgl_konsultasi DESC
");
$query->execute([':id' => $_SESSION['id']]); // Mengambil id_pasien dari sesi pengguna

// Ambil data riwayat konsultasi
$riwayatKonsultasi = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Konsultasi</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Reset beberapa default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            color: #333;
            padding: bold;
        }

        /* Navbar */
        .navbar {
            background: linear-gradient(135deg, #007BFF, #0056b3);
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            display: flex;
            justify-content: flex-end; /* Menempatkan menu di kanan */
            align-items: center;
            z-index: 1000;
        }
        .navbar h1 {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            font-size: 1em;
            margin-right: 50%; /* Memberikan jarak antar tautan */
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            font-size: 1em;
            transition: background-color 0.3s ease, transform 0.2s ease;
            border-radius: 5px;
            margin-left: 10px; /* Memberikan jarak antar tautan */
        }
        .navbar a i {
            margin-right: 8px; /* Memberikan jarak antara ikon dan teks */
        }
        .navbar a:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }
        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            padding: 20px;
        }

        .form-container, .table-container {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 20px;
            flex: 1;
            margin: 10px;
            min-width: 300px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table th {
            background-color: #007bff;
            color: white;
        }

        table tbody tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="dashbordPasien.php">Home</a>
        <a href="daftarPoli.php">Daftar Poli</a>
        <a href="riwayatPoli.php">Riwayat Poli</a>
        <a href="konsultasiPasien.php">Konsultasi</a>
        <a href="riwayatKonsultasi.php">Riwayat Konsultasi</a>
        <a href="logoutPasien.php">Logout</a>
    </div>

    <div class="container">
        <div class="table-container">
            <h3>Riwayat Konsultasi</h3>
            <table border="1">
                <thead>
                    <tr>
                        <th>Tanggal Konsultasi</th>
                        <th>Nama Dokter</th>
                        <th>Keluhan</th>
                        <th>Pertanyaan</th>
                        <th>Jawaban</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($riwayatKonsultasi)): ?>
                        <?php foreach ($riwayatKonsultasi as $riwayat): ?>
                            <tr>
                                <td><?= htmlspecialchars($riwayat['tgl_konsultasi']) ?></td>
                                <td><?= htmlspecialchars($riwayat['nama_dokter']) ?></td>
                                <td><?= htmlspecialchars($riwayat['keluhan']) ?></td>
                                <td><?= htmlspecialchars($riwayat['pertanyaan']) ?></td>
                                <td><?= htmlspecialchars($riwayat['jawaban']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center;">Belum ada riwayat konsultasi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
