<?php
session_start();
require 'db.php'; // Menggunakan koneksi PDO

// Ambil data konsultasi yang belum ditanggapi dokter
$query = $pdo->prepare("
    SELECT k.id, k.keluhan, k.pertanyaan, k.jawaban, k.tgl_konsultasi, p.nama AS nama_pasien, d.nama AS nama_dokter
    FROM konsultasi k
    JOIN pasien p ON k.id_pasien = p.id
    JOIN dokter d ON k.id_dokter = d.id
    WHERE k.jawaban IS NULL
");
$query->execute();

// Ambil semua data konsultasi yang belum ditanggapi
$konsultasiList = $query->fetchAll(PDO::FETCH_ASSOC);

// Tangani pengiriman tanggapan dari dokter
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_konsultasi']) && isset($_POST['tanggapan'])) {
    $id_konsultasi = $_POST['id_konsultasi'];
    $tanggapan = $_POST['tanggapan'];

    // Update tanggapan pada tabel konsultasi
    $updateQuery = $pdo->prepare("UPDATE konsultasi SET jawaban = :jawaban WHERE id = :id_konsultasi");
    $updateQuery->execute([':jawaban' => $tanggapan, ':id_konsultasi' => $id_konsultasi]);

    // Redirect setelah berhasil mengupdate tanggapan
    header("Location: konsultasiDokter.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Konsultasi Dokter</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background: linear-gradient(135deg, #007BFF, #0056b3);
            padding: 20px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            display: flex;
            justify-content: space-around;
            align-items: center;
            z-index: 1000;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            font-size: 1em;
            transition: background-color 0.3s ease, transform 0.2s ease;
            border-radius: 5px;
        }
        .navbar a:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }
        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table th {
            background-color: #007bff;
            color: white;
        }

        table tbody tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
<div class="navbar">
    <a href="dashbordDokter.php"><i class="fa fa-home" aria-hidden="true"></i> Beranda</a>
    <a href="updateDokter.php"><i class="fas fa-user-md"></i> Pembaharui Data Dokter</a>
    <a href="jadwalPeriksa.php"><i class="fas fa-user-injured"></i> Input Jadwal Periksa</a>
    <a href="catatan_kesehatan.php"><i class="fas fa-hospital"></i> Memeriksa Pasien</a>
    <a href="riwayatPeriksa.php"><i class="fas fa-pills"></i> Riwayat Pasien</a>
    <a href="konsultasiDokter.php"><i class="fas fa-id-card"></i> Konsultasi</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="container">
    <div class="form-container">
        <h3>Daftar Konsultasi Pasien</h3>
        <table>
            <thead>
                <tr>
                    <th>Tanggal Konsultasi</th>
                    <th>Nama Pasien</th>
                    <th>Keluhan</th>
                    <th>Pertanyaan</th>
                    <th>Tanggapan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($konsultasiList)): ?>
                    <?php foreach ($konsultasiList as $konsultasi): ?>
                        <tr>
                            <td><?= htmlspecialchars($konsultasi['tgl_konsultasi']) ?></td>
                            <td><?= htmlspecialchars($konsultasi['nama_pasien']) ?></td>
                            <td><?= htmlspecialchars($konsultasi['keluhan']) ?></td>
                            <td><?= htmlspecialchars($konsultasi['pertanyaan']) ?></td>
                            <td>
                                <!-- Form untuk memberi tanggapan -->
                                <form action="konsultasiDokter.php" method="POST">
                                    <input type="hidden" name="id_konsultasi" value="<?= $konsultasi['id'] ?>">
                                    <textarea name="tanggapan" rows="3" class="form-control" placeholder="Masukkan tanggapan" required></textarea>
                                    <button type="submit" class="btn btn-primary mt-2">Kirim Tanggapan</button>
                                </form>
                            </td>
                            <td>
                                <a href="detailKonsultasi.php?id_konsultasi=<?= $konsultasi['id'] ?>" class="btn btn-info">Lihat Detail</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">Belum ada konsultasi untuk ditanggapi</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
